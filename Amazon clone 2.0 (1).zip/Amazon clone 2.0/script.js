                                    // header-slider

const imgs = document.querySelectorAll('.header-slider ul img');
const prev_btn = document.querySelector('.control_prev');
const next_btn = document.querySelector('.control_next');

let n = 0;
function changeSlide(){
    for (let i = 0; i < imgs.length ; i++){
        imgs[i].style.display = 'none';
    }
    imgs[n].style.display = 'block';
}
changeSlide();

prev_btn.addEventListener('click', (e)=> {
    if(n > 0){
        n--;
    } else {
        n= imgs.length - 1;
    }
    changeSlide();
});

next_btn.addEventListener('click', (e)=> {
    if(n < imgs.length - 1){
        n++;
    } else {
        n = 0;
    }
    changeSlide();
});

                                    // products-row slider

const products = document.querySelector('.products');
const prevBtn = document.querySelector('.cont_prev');
const nextBtn = document.querySelector('.cont_next');
const scrollStep = 800;
const scrollSpeed = 300;

prevBtn.addEventListener("click", ()=> {
    products.scrollBy({
        left: -scrollStep,
        behavior: "smooth"
    })
})

nextBtn.addEventListener("click", ()=> {
    products.scrollBy({
        left: scrollStep,
        behavior: "smooth"
    })
})

const products1 = document.querySelector('.products-1');
const prevBtn1 = document.querySelector('.cont_prev-1');
const nextBtn1 = document.querySelector('.cont_next-1');
const scrollStep1 = 800;
const scrollSpeed1 = 300;

prevBtn1.addEventListener("click", ()=> {
    products1.scrollBy({
        left: -scrollStep1,
        behavior: "smooth"
    })
})

nextBtn1.addEventListener("click", ()=> {
    products1.scrollBy({
        left: scrollStep1,
        behavior: "smooth"
    })
})

const products2 = document.querySelector('.products-2');
const prevBtn2 = document.querySelector('.cont_prev-2');
const nextBtn2 = document.querySelector('.cont_next-2');
const scrollStep2 = 800;
const scrollSpeed2 = 300;

prevBtn2.addEventListener("click", ()=> {
    products2.scrollBy({
        left: -scrollStep2,
        behavior: "smooth"
    })
})

nextBtn2.addEventListener("click", ()=> {
    products2.scrollBy({
        left: scrollStep2,
        behavior: "smooth"
    })
})

const products3 = document.querySelector('.products-3');
const prevBtn3 = document.querySelector('.cont_prev-3');
const nextBtn3 = document.querySelector('.cont_next-3');
const scrollStep3 = 800;
const scrollSpeed3 = 300;

prevBtn3.addEventListener("click", ()=> {
    products3.scrollBy({
        left: -scrollStep3,
        behavior: "smooth"
    })
})

nextBtn3.addEventListener("click", ()=> {
    products3.scrollBy({
        left: scrollStep3,
        behavior: "smooth"
    })
})

const products4 = document.querySelector('.products-4');
const prevBtn4 = document.querySelector('.cont_prev-4');
const nextBtn4 = document.querySelector('.cont_next-4');
const scrollStep4 = 800;
const scrollSpeed4 = 300;

prevBtn4.addEventListener("click", ()=> {
    products4.scrollBy({
        left: -scrollStep4,
        behavior: "smooth"
    })
})

nextBtn4.addEventListener("click", ()=> {
    products4.scrollBy({
        left: scrollStep4,
        behavior: "smooth"
    })
})

const products5 = document.querySelector('.products-5');
const prevBtn5 = document.querySelector('.cont_prev-5');
const nextBtn5 = document.querySelector('.cont_next-5');
const scrollStep5 = 800;
const scrollSpeed5 = 300;

prevBtn5.addEventListener("click", ()=> {
    products5.scrollBy({
        left: -scrollStep5,
        behavior: "smooth"
    })
})

nextBtn5.addEventListener("click", ()=> {
    products5.scrollBy({
        left: scrollStep5,
        behavior: "smooth"
    })
})